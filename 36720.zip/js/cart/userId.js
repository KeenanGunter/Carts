// const fs = require("fs");
// const path = require("path");
// const cartListDir = "../../carts.json";
// let cartList = require(cartListDir);

exports.removeOneItem = (req, res, cartList) => {
  console.log(req.body);
  const itemId = req.params.itemId;
  const userId = req.params.userId;
  let foundId = false;


  cartList.forEach((cart) => {
    if(cart.userId == userId) {
      foundId = true
      cart.itemRep.forEach((item, i = 0) => {
        if(item.itemId == itemId) {
          cart.subtotal -= item.itemPrice
          if (item.itemQuantity > 1) {
            item.itemQuantity -= 1;
            cart.cartSize -= 1;
          } else {
            cart.itemRep.splice(i, 1)
            cart.cartSize -= 1
          }
        }
      })
    }
  })

  if (!foundId) {
    res.status(404).json({ error: "User Id not found" });
  } else {
    res.status(200).json({ successMsg: "Successfully removed item from user's cart" })
  }
};

exports.removeAll = (req, res, cartList) => {
  const userId = req.params.userId
  let foundId = false;

  cartList.forEach((cart) => {
    if(cart.userId == userId) {
      cart.itemRep.splice(0, cart.itemRep.length)
      foundId = true
      cart.subtotal = 0
      cart.cartSize = 0
    }
  })

  if (!foundId) {
    res.status(404).json({ error: "User Id not found" })
  } else {
    res.status(200).json({ successMsg: "Deleted all items from user's cart" })
  }
};

exports.getAllItems = (req, res, cartList) => {
  const userId = req.params.userId;
  var userFound = false;

  cartList.forEach((cart) => {
    if(cart.userId == userId ) {
      userFound = true
      res.status(200).json(cart)
    }
  })

  if (!userFound) {
    res.status(404).json({ error: "User Id not found" });
  }
};

exports.addOneItem = (req, res, cartList) => {
  // userId is provided by URI as path param
  const userId = req.params.userId
  // item representation is expected from the body - Tim
  const itemRep = req.body
  let foundId = false;
  //fixed bug that changed all userIds to the userId we are looking for -Aaron
  cartList.forEach((cart) => {
    if( cart.userId == userId ) {
      foundId = true 
      let foundItem = false
      
      cart.itemRep.forEach((item) => {
        if(item.itemId == itemRep.itemId) {
          item.itemQuantity += itemRep.itemQuantity
          cart.cartSize += itemRep.itemQuantity
          cart.subtotal += item.itemPrice * itemRep.itemQuantity
          foundItem = true
        }
      })

      if(!foundItem) {
        cart.itemRep.push(itemRep)
        cart.subtotal += itemRep.itemPrice * itemRep.itemQuantity
      }
    }
  })

  if (!foundId) {
    res.status(404).json({ error: "User Id not found" });
  } else {
    res.status(200).json({
      "successMsg": "Added item to cart"
    })
  }
}

exports.getSubtotal = (req, res, cartList) => {
  var foundId = false;

  cartList.forEach((cart) => {
    if(cart.userId == req.params.userId) {
      res.status(200).json({
        subtotal: cart.subtotal,
      })
      foundId = true
    }
  })

  if(!foundId){
      res.status(404).json({error: "User Id not found"});
  }
}

exports.getItemInfo = (req, res, cartList) => {
  const userId = req.params.userId;
  const itemId = req.params.itemId;
  let userFound = false;
  let itemFound = false;

  cartList.forEach((cart) => {
    if(cart.userId == userId) {
      userFound = true
      cart.itemRep.forEach((item) => {
        if(item.itemId == itemId) {
          itemFound = true
          res.status(200).json(item)
        }
      })
    }
  })

  if (!userFound) {
    res.status(404).json({ error: "User Id not found" });
  } else {
    if (!itemFound) {
      res.status(404).json({ error: "Item Id not found" });
    }
  }
}