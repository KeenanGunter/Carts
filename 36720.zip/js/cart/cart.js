// const fs = require('fs')
// const path = require('path')
// const cartListDir = '../carts.json'
// let cartList = require(cartListDir)

exports.listAllCart = (req, res, cartList) => {
    const timeAfter = (req.query.timeAfter) ? req.query.timeAfter : 0
    let retList = []

    cartList.forEach((cart) => {
        if (cart.cartAge >= timeAfter) {
            retList.push({
                userId: cart.userId,
                cartAge: cart.cartAge,
            })
        }
    })

    if (retList.length > 0) {
        res.status(200)
        res.json(retList)
    } else {
        res.status(404)
        res.json({errMsg: "No carts found"})
    }
}

exports.createCart = (req, res, cartList) => {
    console.log("received request to create new cart")
    const newCartId = req.body
    console.log("creating new cart" + newCartId.userId)

    const newCart = {
        userId: newCartId.userId,
        cartSize: 0,
        cartAge: 0,
        subtotal: 0, 
        itemRep: [],
    }

    cartList.push(newCart)

    res.status(200)
    res.json(newCart)
    //fs.writeFile(cartListDir, JSON.stringify(cartList), err => {
    //    if (err) throw err 
    //    console.log("Wrote " + newCartId + " to cart.json")
    //})
}