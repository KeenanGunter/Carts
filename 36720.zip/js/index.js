const express = require('express')
const fs = require('fs')
const path = require('path')

const app = express()
const LISTEN_PORT = process.env.PORT || '8192'

app.use(express.json())

const cart = require('./cart/cart')
const userId = require('./cart/userId')

// Heroku only provides a READONLY fs, so no writing.
// const cartListDir = path.join(__dirname, 'carts.json')
// let cartList = require(cartListDir)

// Arrays are pass by reference - Tim
let cartList = []

app.route("/cart")
    .get((req, res) => cart.listAllCart(req, res, cartList))
    .post((req, res) => cart.createCart(req, res, cartList));

app.route("/cart/:userId")
    .get((req, res) => userId.getAllItems(req, res, cartList))   
    .post((req, res) => userId.addOneItem(req, res, cartList));

app.route("/cart/:userId/subtotal")
    .get((req, res) => userId.getSubtotal(req, res, cartList));

app.route("/cart/:userId/removeAll")
    .delete((req, res) => userId.removeAll(req, res, cartList));

app.route("/cart/:userId/:itemId")
    .delete((req, res) => userId.removeOneItem(req, res, cartList))
    .get((req, res) => userId.getItemInfo(req, res, cartList));

app.listen(LISTEN_PORT, () => {
    console.log("Listening on " + LISTEN_PORT)
})
